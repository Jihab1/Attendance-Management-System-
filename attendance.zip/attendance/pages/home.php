<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Attendance System</title>
  <!-- Google Font Link -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    /* General Style */
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: #f7f7f7; /* Light grey background */
      color: #333; /* Default text color */
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    header {
      background: #333; /* Dark black background */
      color: white;
      text-align: center;
      padding: 50px 0;
      font-size: 32px;
      font-weight: 600;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    /* Main Section */
    .main-container {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 40px;
    }

    .welcome-message {
      font-size: 24px;
      color: #333; /* Dark grey text */
      font-weight: 600;
      margin-top: 20px;
    }

    .info-box {
      background-color: white;
      border-radius: 12px;
      padding: 40px;
      max-width: 500px;
      margin-top: 30px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease-in-out, box-shadow 0.3s ease;
    }

    .info-box:hover {
      transform: translateY(-10px); /* Hover effect */
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
    }

    .info-box h2 {
      font-size: 28px;
      font-weight: 600;
      color: #333; /* Dark grey for heading */
      margin-bottom: 15px;
    }

    .info-box p {
      font-size: 18px;
      color: #555; /* Lighter grey for paragraph text */
      line-height: 1.6;
      margin-bottom: 15px;
    }

    /* Footer */
    footer {
      background-color: #333; /* Dark background for footer */
      color: white;
      text-align: center;
      padding: 20px;
      font-size: 14px;
      position: relative;
    }

    footer p {
      margin: 0;
    }

    
  </style>
</head>
<body>

<header>
  <h1>Attendance Management System</h1>
</header>

<div class="main-container">
  <div class="welcome-message">
    <p>Welcome to the Attendance System</p>
    <p>Track, manage, and analyze attendance easily and efficiently.</p>
  </div>

  <div class="info-box">
    <h2>System Overview</h2>
    <p>This system allows you to monitor attendance records, track student presence, and generate detailed reports.</p>
    <p>Stay tuned for future features like notifications and automatic attendance generation!</p>
  </div>
</div>

<footer>
  <p>&copy; 2024 Attendance System. All Rights Reserved.</p>
</footer>

</body>
</html>
