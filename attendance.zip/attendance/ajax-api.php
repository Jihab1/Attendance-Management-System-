<?php 
session_start();
require_once('classes/actions.semester.php'); // Update the class file name if necessary
$actionSemester = new Actions();
$action = $_GET['action'] ?? "";
$response = [];
switch($action){
    case 'save_semester':
        $response = $actionSemester->save_semester();
        break;
    case 'delete_semester':
        $response = $actionSemester->delete_semester();
        break;
        case 'save_student':
    case 'save_student':
        $response = $actionSemester->save_student();
        break;
    case 'delete_student':
        $response = $actionSemester->delete_student();
        break;
    case 'save_attendance':
        $response = $actionSemester->save_attendance();
        break;
    default:
        $response = ["status" => "error", "msg" => "Undefined API Action!"];
        break;
}

echo json_encode($response);
?>